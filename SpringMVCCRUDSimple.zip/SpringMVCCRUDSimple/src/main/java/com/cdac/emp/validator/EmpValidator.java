package com.cdac.emp.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.cdac.emp.beans.Emp;


@Component
public class EmpValidator implements Validator{

	
	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Emp.class.equals(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {

	      ValidationUtils.rejectIfEmpty(errors, "name", "emp.name.empty");
	     ValidationUtils.rejectIfEmpty(errors, "dob", "emp.dob.empty");
	      Emp emp = (Emp) obj;
	      ValidationUtils.rejectIfEmpty(errors, "phno", "emp.phno.empty");
	      ValidationUtils.rejectIfEmpty(errors, "email", "emp.email.empty");
	      ValidationUtils.rejectIfEmpty(errors, "gender", "emp.gender.empty");
	      ValidationUtils.rejectIfEmpty(errors, "city", "emp.city.empty");
	      ValidationUtils.rejectIfEmpty(errors, "food", "emp.food.empty");

	      

	      Pattern pattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
	            Pattern.CASE_INSENSITIVE);
	      if (!(pattern.matcher(emp.getEmail()).matches())) {
	    	  errors.rejectValue("email", "emp.email.invalid");
	      }
	      

	      Pattern pattern1 = Pattern.compile("(0/+91)?[7-9][0-9]{9}",
	              Pattern.CASE_INSENSITIVE);
	        if (!(pattern1.matcher(emp.getPhno()).matches())) {
	        	errors.rejectValue("phno", "emp.phno.invalid");
	           
	           
	        }
		
	}

}
