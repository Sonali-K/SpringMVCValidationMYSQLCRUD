package com.cdac.emp.controllers; 
import java.util.List;    
import org.springframework.beans.factory.annotation.Autowired;    
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;    
import org.springframework.web.bind.annotation.PathVariable;    
import org.springframework.web.bind.annotation.RequestMapping;    
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.emp.beans.Emp;
import com.cdac.emp.dao.EmpDao;
import com.cdac.emp.validator.EmpValidator;   


@Controller    
public class EmpController {    
	@Autowired    
	EmpDao dao;//will inject dao from XML file  
	
	@Autowired
	private EmpValidator empValidator;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.addValidators(empValidator);
	}

	/*It displays a form to input data, here "command" is a reserved request attribute  
	 *which is used to display object data into form  
	 */ 

	@RequestMapping("/loginform")    
	public String showloginform(Model m){    
		m.addAttribute("emp", new Emp());  
		return "loginform";   
	}    
	@RequestMapping("/empform")    
	public String showform(Model m){    
		m.addAttribute("emp", new Emp());  
		return "empform";   
	} 
	@RequestMapping(value = "/submit", method = RequestMethod.POST)  
	public String index() { 
		{
			return "redirect:/empform"; 
		}
	}  

	/*It saves object into database. The @ModelAttribute puts request data  
	 *  into model object. You need to mention RequestMethod.POST method   
	 *  because default request is GET*/    
	@RequestMapping(value="/save",method = RequestMethod.POST)    
	public String save(@ModelAttribute("emp")  @Validated Emp emp,BindingResult result){    


	/*	if (result.hasErrors()) {
			return "empform";
		}
			return "redirect:/viewemp";//will redirect to viewemp request mapping   */
		// dao.save(emp); 
		//emp1.save(emp);
		
	
		if (result.hasErrors()) {
			return "empform";
		} else {
			dao.save(emp);    
			return "redirect:/viewemp";
		}

 
	}    
	/* It provides list of employees in model object */    
	@RequestMapping("/viewemp")    
	public String viewemp(Model m){    
		List<Emp> list=dao.getEmployees();    
		m.addAttribute("list",list);  
		return "viewemp";    
	}    
	/* It displays object data into form for the given id.   
	 * The @PathVariable puts URL data into variable.*/    
	@RequestMapping(value="/editemp/{id}")    
	public String edit(@PathVariable int id, Model m){    
		Emp emp=dao.getEmpById(id);    
		m.addAttribute("command",emp);  
		return "empeditform";    
	}    
	/* It updates model object. */    
	@RequestMapping(value="/editsave",method = RequestMethod.POST)    
	public String editsave(@ModelAttribute("emp") Emp emp){    
		dao.update(emp);    
		return "redirect:/emp/viewemp";    
	}    
	/* It deletes record for the given id in URL and redirects to /viewemp */    
	@RequestMapping(value="/deleteemp/{id}",method = RequestMethod.GET)    
	public String delete(@PathVariable int id){    
		dao.delete(id);    
		return "redirect:/viewemp";    
	}     
}  
